$environmentName = $OctopusParameters['Octopus.Environment.Name']
Write-Host "OctopusParameter: $environmentName"
Write-Host "InlineVariable: $OctopusEnvironmentName"
Write-Host "VariableSubstitution: #{Octopus.Environment.Name}!"